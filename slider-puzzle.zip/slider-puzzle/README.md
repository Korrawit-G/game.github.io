# Slider Puzzle

A Pen created on CodePen.

Original URL: [https://codepen.io/dustindwayne/pen/YPWVZEo](https://codepen.io/dustindwayne/pen/YPWVZEo).

